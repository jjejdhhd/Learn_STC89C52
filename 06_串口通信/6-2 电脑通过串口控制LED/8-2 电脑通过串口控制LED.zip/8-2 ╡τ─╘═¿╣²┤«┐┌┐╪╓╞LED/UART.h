#ifndef __UART_H__
#define __UART_H__

void UART_Init(); // 串口初始化
void UART_SendByte(unsigned char Byte); // 串口发送1Byte数据

#endif