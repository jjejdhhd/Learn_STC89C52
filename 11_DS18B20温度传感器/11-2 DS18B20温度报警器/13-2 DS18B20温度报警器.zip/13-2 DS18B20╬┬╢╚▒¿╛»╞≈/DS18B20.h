#ifndef __DS18B02_H__
#define __DS18B02_H__

void DS18B20_ConvertTemp(void);// 温度转换
float DS18B20_ReadTemp(void);// 温度读取

#endif