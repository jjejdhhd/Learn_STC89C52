#ifndef __AT24C02_H__
#define __AT24C02_H__

unsigned char AT24C02_WriteByte(unsigned char wr_addr,wr_byte);//字节写
unsigned char AT24C02_ReadByte(unsigned char rd_addr);//随机读
  
#endif