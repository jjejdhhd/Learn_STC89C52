#ifndef __MATRIX_LED_H__
#define __MATRIX_LED_H__

MatrixLED_ShowColumn(unsigned char Column,Data); // 控制LED点阵的某一列显示

#endif