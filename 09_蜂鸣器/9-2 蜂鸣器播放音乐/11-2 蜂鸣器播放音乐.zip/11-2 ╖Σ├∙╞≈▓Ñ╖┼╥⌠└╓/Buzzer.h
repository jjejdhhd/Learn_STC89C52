#ifndef __BUZZER_H__
#define __BUZZER_H__

void Buzzer_Time(unsigned int ms);//1000Hz，持续ms个毫秒

#endif